public class Mechanics {
}
