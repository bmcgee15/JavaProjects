public class Human extends Humanoid{

}
